//
//  ViewController.swift
//  Week9-prac8
//
//  Created by HYUNGJIN KIM on 8/5/18.
//  Copyright © 2018 HYUNGJIN KIM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

        @IBOutlet weak var WEB: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let facebook = "http://www.facebook.com/"
        WEB.loadRequest(URLRequest(url: (URL(string: facebook))!))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

