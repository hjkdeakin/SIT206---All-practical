//
//  TripAnnotation.swift
//  Trip Gallery - week6
//
//  Created by HYUNGJIN KIM on 24/4/18.
//  Copyright © 2018 HYUNGJIN KIM. All rights reserved.
//
import UIKit
import MapKit


class TripAnnotation: NSObject,MKAnnotation {
    var tripId : Int
    var title: String?
    var subtitle: String?
    var coordinate: CLLocationCoordinate2D
    var img : UIImage?
    
    init(tripId : Int, trip : Trip, coordinate : CLLocationCoordinate2D) {
        self.tripId = tripId
        self.title = trip.tripDestination
        self.subtitle = "\(trip.tripDate)"
        self.coordinate = coordinate
        self.img = trip.destinationImage
        
    }
    
}
